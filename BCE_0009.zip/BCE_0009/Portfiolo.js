<script>
    var tablinks = documents.
</script>